<?php
echo password_hash('adminpass', PASSWORD_DEFAULT) . "\n";
echo password_hash('clientpass', PASSWORD_DEFAULT) . "\n";
?>