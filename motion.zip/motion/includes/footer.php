<hr>
<footer>
    <p>&copy; 2025 Motion. Tous droits réservés.</p>
</footer>
</body>
</html>
